package it.mirianamarchi.seleniumtest;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class KgPoundTest {

    private static float getValue() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\mmarc\\Desktop\\Selenium\\Selenium\\src\\test\\java\\it\\mirianamarchi\\seleniumtest\\driver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.cleancss.com/convert-units/units-of-weight/kg/lb");
        driver.manage().window().setSize(new Dimension(1265, 1372));
        driver.findElement(By.xpath("//*[@id=\"main-segment\"]/div[3]/form/div/input")).click();
        driver.findElement(By.xpath("//*[@id=\"main-segment\"]/div[3]/form/div/input")).clear();
        driver.findElement(By.xpath("//*[@id=\"main-segment\"]/div[3]/form/div/input")).sendKeys("3");
        driver.findElement(By.xpath("//*[@id=\"main-segment\"]/div[3]/form/input")).click();
        Thread.sleep(1000);
        WebElement value = driver.findElement(By.xpath("//*[@id=\"main-segment\"]/div[4]/div[3]/div[1]"));
        float res = Float.parseFloat(value.getText());
        System.out.println(res);
        driver.close();
        return res;
    }

    @Test
    public void testValue() throws InterruptedException {
        float res = getValue();
        assertTrue(res>6.00);
    }
}
